var classstefanfrings_1_1StaticFileController =
[
    [ "StaticFileController", "classstefanfrings_1_1StaticFileController.html#a8ddcf4fc3db1fdc25ddafec29f0d05b2", null ],
    [ "service", "classstefanfrings_1_1StaticFileController.html#a88bbd874c62c8335d0775629b22871a1", null ]
];