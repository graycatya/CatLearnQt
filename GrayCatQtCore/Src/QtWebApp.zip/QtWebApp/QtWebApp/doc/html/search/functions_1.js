var searchData=
[
  ['dualfilelogger_206',['DualFileLogger',['../classstefanfrings_1_1DualFileLogger.html#a8368cfe85bbc2e56f9d1cd0593c7c925',1,'stefanfrings::DualFileLogger']]]
];
