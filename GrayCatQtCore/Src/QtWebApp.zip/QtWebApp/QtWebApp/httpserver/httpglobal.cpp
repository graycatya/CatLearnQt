#include "httpglobal.h"

const char* getQtWebAppLibVersion()
{
    return "1.8.4";
}

